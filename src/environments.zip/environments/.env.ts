// IMPORTANT: THIS FILE IS AUTO GENERATED! DO NOT MANUALLY EDIT OR CHECKIN!
/* tslint:disable */
export default {
  'mifos_x': {
    'version': '251022',
    'hash': 'g62c278e4'
  },
  'allow_switching_backend_instance': true
};
/* tslint:enable */
