import { Component } from '@angular/core';

@Component({
  selector: 'mifosx-self-service',
  templateUrl: './self-service.component.html',
  styleUrls: ['./self-service.component.scss']
})
export class SelfServiceComponent { }