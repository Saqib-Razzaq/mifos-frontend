import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, map, Observable } from 'rxjs';
import { AuthenticationService } from '../core/authentication/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class OverviewService {
  private officeId: number;

  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) {
    const credentials = this.authService.getCredentials();
    this.officeId = credentials?.officeId ?? 1;
  }

  getDashboardData(): Observable<any> {
    return forkJoin({
      clientTrends: this.http.get(
        `/runreports/ClientTrendsByMonth?R_officeId=${this.officeId}&ResultSet=false`
      ),
      loanTrends: this.http.get(
        `/runreports/LoanTrendsByMonth?R_officeId=${this.officeId}&ResultSet=false`
      ),
      statement: this.http.get(
        `/runreports/Income%20Statement%20Table?locale=en&R_endDate=2024-12-31&R_startDate=2024-12-01&R_officeId=${this.officeId}`
      )
      // If you have a separate savings report, uncomment and add below
      // savingsDetails: this.http.get(`/runreports/SavingsSummary?R_officeId=${this.officeId}`)
    }).pipe(
      map((data) => this.mapToMetrics(data))
    );
  }

  private mapToMetrics(data: any): any {
    const client = data.clientTrends?.data?.[0] ?? {};
    const loans = data.loanTrends?.data?.[0] ?? {};
    const income = data.statement?.data?.[0] ?? {};
    // const savingsDetail = data.savingsDetails?.data?.[0] ?? {};

    return {
      customers: {
        all: client.allClients ?? 0,
        active: client.activeClients ?? 0,
        inactive: client.inactiveClients ?? 0,
        new: client.newClients ?? 0,
      },
      loans: {
        principalOutstanding: loans.principal_outstanding ?? 0,
        interestOutstanding: loans.interest_outstanding ?? 0,
        chargesOutstanding: loans.charges_outstanding ?? 0,
        totalOutstanding: loans.total_outstanding ?? 0,
      },
      loanOverdue: {
        principal: loans.principal_overdue ?? 0,
        interest: loans.interest_overdue ?? 0,
        charges: loans.charges_overdue ?? 0,
        total: loans.total_overdue ?? 0,
      },
      overpaidLoans: loans.overpaid_loans ?? 0,
      expectedPayments: income.expectedPayments ?? 0,
      pendingApproval: loans.pending_approval ?? 0,
      pendingDisbursal: loans.pending_disbursal ?? 0,
      disbursedToday: loans.disbursed_today ?? 0,
      savings: {
        total: income.total_savings ?? 0,
        // Use real fields if your report returns them
        fixedDeposits: income.fixed_deposits ?? income.fixedDeposits ?? 0,
        recurrentDeposits: income.recurrent_deposits ?? income.recurringDeposits ?? 0,
        // Or fallback to 0 if not available
        // fixedDeposits: savingsDetail.fixedDeposits ?? 0,
        // recurrentDeposits: savingsDetail.recurrentDeposits ?? 0,
      }
    };
  }

  setOffice(officeId: number): void {
    this.officeId = officeId;
  }

  fetchOfficeIdFromAPI(): Observable<number> {
    return this.http.get<any>('users/my-office').pipe(
      map((resp) => {
        this.officeId = resp.officeId;
        return resp.officeId;
      })
    );
  }
}