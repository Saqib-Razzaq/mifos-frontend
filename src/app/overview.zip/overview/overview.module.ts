import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { OverviewRoutingModule } from './overview-routing.module';
import { OverviewComponent } from './overview.component';
import { SharedModule } from '../shared/shared.module';   // ← THIS ONE!

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    OverviewRoutingModule,
    OverviewComponent // ⬅️ standalone component import ONLY
  ]
})
export class OverviewModule {}
