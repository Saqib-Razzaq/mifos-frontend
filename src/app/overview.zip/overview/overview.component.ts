import { Component, OnInit, OnDestroy } from '@angular/core';
import { OverviewService } from './overview.service';
import { Subscription } from 'rxjs';

// Material Imports
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CommonModule } from '@angular/common';
import { CurrencyPipe, DecimalPipe } from '@angular/common';

@Component({
  selector: 'mifosx-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss'],
  standalone: true, // ← keep false if it's declared in a NgModule (like OverviewModule)
  imports: [
    // Add these
    CommonModule,
    CurrencyPipe,
    DecimalPipe,
    MatIconModule,
    MatButtonModule,
    MatProgressSpinnerModule
  ]
})
export class OverviewComponent implements OnInit, OnDestroy {
  metrics: any = {
    customers: {},
    loans: {},
    loanOverdue: {},
    savings: {}
  };
  loading = true;
  error = false;

  private subscription = new Subscription();

  constructor(private overviewService: OverviewService) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  private loadDashboardData(): void {
    this.loading = true;
    this.error = false;

    this.subscription.add(
      this.overviewService.getDashboardData().subscribe({
        next: (data) => {
          this.metrics = data;
          this.loading = false;
        },
        error: (err) => {
          console.error('Failed to load dashboard metrics', err);
          this.error = true;
          this.loading = false;
        }
      })
    );
  }

  refresh() {
    this.loadDashboardData();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}