import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OverviewComponent } from './overview.component';
/** Layout Component (Shell) */
import { ShellComponent } from '../core/shell/shell.component';


const routes: Routes = [
  {
    path: '',
    component: ShellComponent, // ✅ Wrap inside main app shell (includes toolbar + sidebar)
    children: [
      {
        path: '',
        component: OverviewComponent,
        data: {
          title: 'Overview',
          breadcrumb: 'Overview',
          addBreadcrumbLink: false
        }
      }
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OverviewRoutingModule { }
